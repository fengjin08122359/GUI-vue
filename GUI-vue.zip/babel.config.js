module.exports = {
  presets: [
    '@vue/app'
  ],
  ignore: ['@mikefeng110808/micro-util']
}
