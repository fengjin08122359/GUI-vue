import sdk from '../../sdk'

const state = {
}
const getters = {
}
const mutations = {
  
}
const actions = {
  init () {
    sdk.init()
  },
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
}